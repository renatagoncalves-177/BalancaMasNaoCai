<?php
	session_start();

	try {
		// pega usuario e senha passados
		$usuario = $_POST['email'];
		$senha = $_POST['senha'];

		// conex�o
		include_once "conexao.php";

		$conn = mysqli_connect($localhost, $user, $password, $banco);

		if (!$conn) {
			header('Location: index.html');
		}
	
		// monta query
		$sql = "SELECT * FROM usuarios WHERE (Email='$usuario') AND (Senha='$password')";
		$result = mysqli_query($conn, $sql);
		$row = mysqli_num_rows($result);

		// testa retorno
		if ($row > 0) {
			while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
				$usuario = $row["Nome"];
				$email = $row["Email"];
				$senha = $row["Senha"];
			}

			$_SESSION['usuario'] = $usuario;
			$_SESSION['dsEmail'] = $email;
			$_SESSION['senha'] = $senha;

			header('Location: menu.php');
		} else {
			header('Location: index.html');
		}
	} catch (Exception $e) {
		header('Location: index.html');
	}
?>