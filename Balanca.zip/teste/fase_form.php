<?php
session_start();
if (!isset($_SESSION['logado'])) { header('Location: index.php'); exit; }
include_once "conexao.php";


$idFase = $_GET['id'] ?? null;
$dsFase = '';

if ($idFase) {
    $sql = "SELECT dsFase FROM fases WHERE idFase = $idFase";
    $result = mysqli_query($conn, $sql);
    if ($row = mysqli_fetch_assoc($result)) {
        $dsFase = $row['dsFase'];
    }
}
?>
<html>
<head>
    <title><?= $idFase ? 'Editar' : 'Nova' ?> Fase</title>
</head>
<body>
    <div>
        <h2><?= $idFase ? 'Editar' : 'Nova' ?> Fase</h2>
        
        <form method="post" action="fase_acao.php">
            <input type="hidden" name="acao" value="<?= $idFase ? 'alterar' : 'incluir' ?>">
            <?php if ($idFase): ?>
                <input type="hidden" name="idFase" value="<?= $idFase ?>">
            <?php endif; ?>


            <div>
                <label>Descrição da Fase</label>
                <input type="text" name="dsFase" value="<?= htmlspecialchars($dsFase) ?>" required autofocus>
            </div>


            <div>
                <a href="fases.php" class="btn btn-gray">Cancelar</a>
                <button type="submit" class="btn btn-red">Salvar Dados</button>
            </div>
        </form>
    </div>
</body>
</html>