<?php
session_start();
include_once "conexao.php";


$acao = $_POST['acao'] ?? $_GET['acao'] ?? '';


if ($acao === 'incluir') {
    $dsFase = $_POST['dsFase'];
    $sql = "INSERT INTO fases (dsFase) VALUES ('$dsFase')";
    mysqli_query($conn, $sql);
} 
elseif ($acao === 'alterar') {
    $idFase = $_POST['idFase'];
    $dsFase = $_POST['dsFase'];
    $sql = "UPDATE fases SET dsFase = '$dsFase' WHERE idFase = $idFase";
    mysqli_query($conn, $sql);
} 
elseif ($acao === 'excluir') {
    $idFase = $_GET['id'];
    $sql = "DELETE FROM fases WHERE idFase = $idFase";
    mysqli_query($conn, $sql);
}


header('Location: fases.php');
exit;
?>