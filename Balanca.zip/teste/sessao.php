<?php
	session_start();
	
	try {
		// conex�o
		include_once "conexao.php";

		$conn = mysqli_connect($localhost, $user, $password, $banco);

		if (!$conn) {
			header('Location: logout.php');
		}

		// abre sess�o
		if ((!isset($_SESSION["usuario"])) || (!isset($_SESSION["senha"]))) {
			header("Location: index.html");
		} else {
			$usuario = $_SESSION["usuario"];
			$email = $_SESSION['dsEmail'];
			$senha = $_SESSION["senha"];
		}
	} catch (Exception $e) {
		header('Location: index.html');
	}
?>