<?php
session_start();
if (!isset($_SESSION['logado'])) { header('Location: index.html'); exit; }
?>
<html>
<head>
    <title>Menu Principal</title>
</head>
<body>
    <center>
        <h2>Menu</h2>
        <p>Bem-vindo(a), <strong><?= $_SESSION['email'] ?></strong></p>
        
        <ul class="menu-list">
            <li><a href="#">Obras</a></li>
            <li><a href="#">Engenheiros</a></li>
            <li><a href="#">Orçamentos</a></li>
            <li><a href="fases.php">Fases</a></li>
        </ul>

        <li><a href="logout.php">Sair do Sistema</a></li>
    </center>
</body>