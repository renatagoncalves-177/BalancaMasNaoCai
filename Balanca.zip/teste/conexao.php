<?php
	$localhost = "192.168.20.5";
	$user = "root";
	$password = "12345";
	$banco = "balanca_mas_nao_cai";
?>