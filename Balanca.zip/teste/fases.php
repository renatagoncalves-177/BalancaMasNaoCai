<?php
session_start();
if (!isset($_SESSION['logado'])) { header('Location: index.php'); exit; }
include_once "conexao.php";


$sql = "SELECT * FROM fases ORDER BY idFase ASC";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <title>Fases</title>
</head>
<body>
    <center>
        <h2>Fases da Obra</h2>
        <div>
            <a href="menu.php">Voltar</a>
            <a href="fase_form.php">Nova Fase</a>
        </div>


        <table>
            <thead>
                <tr>
                    <th>Código</th> 
                    <th>Descrição da Fase</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = mysqli_fetch_assoc($result)) : ?>
                    <tr>
                        <td><?= htmlspecialchars($row['idFase']) ?></td>
                        <td><?= htmlspecialchars($row['dsFase']) ?></td>
                        <td>
                            <a href="fase_form.php?id=<?= $row['idFase'] ?>" >Alterar</a>
                            <a href="fase_acao.php?acao=excluir&id=<?= $row['idFase'] ?>>Excluir</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </center>
</body>
</html>